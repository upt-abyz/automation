from github import Github

g = Github("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")


def protect_branch(target_repo):
	repo = g.get_repo("upt-abyz/" + target_repo)
	branch = repo.get_branch("main")
	branch.edit_protection(required_approving_review_count=2, enforce_admins=True)

protect_branch("test")


"""
Your module description
"""
from github import Github

g = Github("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")


def protect_branch(target_repo):
	repo = g.get_repo("upt-abyz/" + target_repo)
	branch = repo.get_branch("main")
	branch.edit_protection(required_approving_review_count=2, enforce_admins=True)

protect_branch("test")